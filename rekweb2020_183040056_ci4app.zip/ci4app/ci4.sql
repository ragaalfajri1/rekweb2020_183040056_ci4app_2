-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2020 at 11:35 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Table structure for table `komik`
--

CREATE TABLE `komik` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `sampul` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `komik`
--

INSERT INTO `komik` (`id`, `judul`, `slug`, `penulis`, `penerbit`, `sampul`, `created_at`, `updated_at`) VALUES
(1, 'Naruto', 'naruto', 'Masashi Kishimoto', 'Shonen Jump', 'naruto.jpg', NULL, '2020-10-16 02:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2020-10-16-182614', 'App\\Database\\Migrations\\Orang', 'default', 'App', 1602873304, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orang`
--

CREATE TABLE `orang` (
  `id` int(11) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang`
--

INSERT INTO `orang` (`id`, `nama`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'Fitriani Icha Usada', 'Ds. Lumban Tobing No. 939, Bima 81807, SumUt', '1979-06-22 19:53:42', '2020-10-16 14:20:57'),
(2, 'Anom Sinaga S.Pd', 'Ki. Tambun No. 638, Tidore Kepulauan 83571, JaTeng', '1973-10-14 14:00:05', '2020-10-16 14:20:57'),
(3, 'Ajiman Sihombing S.Kom', 'Ds. Suprapto No. 416, Palembang 31088, KalSel', '1988-10-27 11:41:11', '2020-10-16 14:20:57'),
(4, 'Kenari Hutasoit S.H.', 'Gg. Adisumarmo No. 471, Sorong 17998, Papua', '1996-10-11 20:56:28', '2020-10-16 14:20:57'),
(5, 'Wawan Ramadan M.Pd', 'Gg. Untung Suropati No. 467, Solok 81764, Papua', '1978-01-13 17:17:40', '2020-10-16 14:20:57'),
(6, 'Elvina Ilsa Hastuti S.T.', 'Gg. Bazuka Raya No. 701, Prabumulih 97510, Riau', '1970-03-04 09:52:56', '2020-10-16 14:20:57'),
(7, 'Kasusra Nyana Manullang', 'Ki. Abdul. Muis No. 111, Administrasi Jakarta Utara 85420, JaTim', '2014-08-26 14:13:54', '2020-10-16 14:20:57'),
(8, 'Ikin Prasasta', 'Gg. Warga No. 147, Padangsidempuan 20306, BaBel', '2012-10-25 11:58:17', '2020-10-16 14:20:58'),
(9, 'Cakrajiya Adinata Pratama S.Psi', 'Ds. Ters. Jakarta No. 842, Lubuklinggau 56722, KepR', '2012-09-07 16:13:07', '2020-10-16 14:20:58'),
(10, 'Cemeti Uwais', 'Gg. Yohanes No. 272, Tebing Tinggi 10563, Gorontalo', '1996-02-21 10:06:53', '2020-10-16 14:20:58'),
(11, 'Edi Maryadi', 'Ds. Bagonwoto  No. 698, Sabang 79565, Bengkulu', '1987-06-05 10:10:25', '2020-10-16 14:20:58'),
(12, 'Elvina Maryati', 'Dk. Bhayangkara No. 324, Administrasi Jakarta Barat 35187, SulTeng', '1983-03-01 05:36:14', '2020-10-16 14:20:58'),
(13, 'Paiman Jaka Pradana S.E.I', 'Gg. Ujung No. 867, Tidore Kepulauan 48151, KepR', '1973-12-31 07:10:19', '2020-10-16 14:20:58'),
(14, 'Lidya Zulfa Hastuti', 'Kpg. Wahid No. 603, Palopo 69264, Maluku', '1995-06-10 19:46:44', '2020-10-16 14:20:58'),
(15, 'Devi Zahra Oktaviani S.T.', 'Jr. Bawal No. 335, Jambi 87235, SulTeng', '1990-05-11 23:32:35', '2020-10-16 14:20:58'),
(16, 'Limar Kuswoyo', 'Jln. Baja No. 117, Jayapura 92144, KalTeng', '2012-05-19 18:22:21', '2020-10-16 14:20:58'),
(17, 'Febi Uyainah', 'Dk. Diponegoro No. 814, Sorong 34757, JaTim', '2009-01-13 10:50:22', '2020-10-16 14:20:58'),
(18, 'Julia Handayani', 'Ds. B.Agam 1 No. 772, Batu 33298, JaTim', '2017-02-02 20:05:36', '2020-10-16 14:20:58'),
(19, 'Manah Utama', 'Kpg. Nangka No. 392, Padangpanjang 64170, KalSel', '1988-11-22 20:36:44', '2020-10-16 14:20:58'),
(20, 'Jabal Nugroho', 'Jln. Bara No. 43, Tomohon 97297, Bali', '1998-05-01 19:37:46', '2020-10-16 14:20:58'),
(21, 'Samiah Kusmawati', 'Jln. Baya Kali Bungur No. 63, Denpasar 36288, SulBar', '1970-07-01 17:51:05', '2020-10-16 14:20:58'),
(22, 'Tomi Pradipta', 'Gg. Pasteur No. 969, Pematangsiantar 38333, JaBar', '2006-06-15 01:09:11', '2020-10-16 14:20:58'),
(23, 'Ciaobella Usyi Kuswandari', 'Ki. Yohanes No. 986, Sibolga 60827, PapBar', '1986-10-01 19:55:44', '2020-10-16 14:20:58'),
(24, 'Narji Damanik', 'Ki. Taman No. 667, Metro 26708, Bali', '2003-08-20 21:55:53', '2020-10-16 14:20:58'),
(25, 'Ilyas Gunarto', 'Dk. Dipenogoro No. 328, Dumai 61083, SulSel', '1984-06-30 02:24:33', '2020-10-16 14:20:58'),
(26, 'Darimin Hakim', 'Dk. Soekarno Hatta No. 621, Salatiga 48482, MalUt', '2015-10-10 04:34:42', '2020-10-16 14:20:58'),
(27, 'Asmuni Prasasta', 'Kpg. Uluwatu No. 866, Malang 25957, Banten', '1980-03-15 11:04:41', '2020-10-16 14:20:59'),
(28, 'Ida Sari Fujiati S.E.I', 'Ds. Gedebage Selatan No. 635, Pagar Alam 62758, Bengkulu', '1989-12-14 22:33:08', '2020-10-16 14:20:59'),
(29, 'Violet Usamah S.T.', 'Jln. Samanhudi No. 606, Makassar 76822, JaTim', '2010-04-19 15:29:13', '2020-10-16 14:20:59'),
(30, 'Vivi Indah Puspita', 'Kpg. Baik No. 805, Batu 99585, DKI', '2019-12-26 17:09:38', '2020-10-16 14:20:59'),
(31, 'Eli Haryanti', 'Ds. Ki Hajar Dewantara No. 331, Bogor 22644, JaBar', '2010-04-30 07:29:43', '2020-10-16 14:20:59'),
(32, 'Wardaya Sitorus S.I.Kom', 'Jln. Baan No. 188, Tanjung Pinang 99419, JaTim', '1987-01-13 21:56:29', '2020-10-16 14:20:59'),
(33, 'Nadia Halimah', 'Jln. W.R. Supratman No. 3, Palangka Raya 20153, SumUt', '1994-01-24 14:02:08', '2020-10-16 14:20:59'),
(34, 'Ellis Utami', 'Jln. Ters. Jakarta No. 62, Binjai 38938, DKI', '2000-11-03 08:38:19', '2020-10-16 14:20:59'),
(35, 'Ajeng Raina Melani S.Kom', 'Kpg. B.Agam Dlm No. 766, Surabaya 29013, Gorontalo', '1978-02-02 16:00:15', '2020-10-16 14:20:59'),
(36, 'Gading Ramadan', 'Jln. Tangkuban Perahu No. 205, Pematangsiantar 75427, PapBar', '1975-05-21 02:14:15', '2020-10-16 14:20:59'),
(37, 'Lamar Hakim', 'Jr. Baranang No. 757, Tidore Kepulauan 98924, Banten', '2003-09-04 04:53:26', '2020-10-16 14:20:59'),
(38, 'Anggabaya Rama Marpaung S.H.', 'Ds. Dr. Junjunan No. 515, Tomohon 87589, DKI', '2012-06-12 12:16:53', '2020-10-16 14:20:59'),
(39, 'Kenzie Zulkarnain', 'Ki. Ujung No. 59, Kupang 53143, SulUt', '1980-01-21 12:38:48', '2020-10-16 14:20:59'),
(40, 'Muni Firmansyah', 'Dk. Otto No. 691, Probolinggo 74003, PapBar', '1983-01-30 13:54:21', '2020-10-16 14:20:59'),
(41, 'Tirta Galur Tarihoran S.E.', 'Dk. Nanas No. 748, Administrasi Jakarta Utara 61639, Lampung', '2012-01-15 21:11:46', '2020-10-16 14:20:59'),
(42, 'Dinda Yani Nasyiah S.T.', 'Gg. Peta No. 199, Padangsidempuan 85257, DKI', '1982-01-23 01:21:40', '2020-10-16 14:20:59'),
(43, 'Saadat Asman Wibowo', 'Jr. Basoka Raya No. 249, Tasikmalaya 57261, SulSel', '2019-01-21 14:21:50', '2020-10-16 14:20:59'),
(44, 'Wira Saefullah S.T.', 'Jln. Bagonwoto  No. 351, Batu 47085, SumSel', '1975-08-14 17:49:10', '2020-10-16 14:20:59'),
(45, 'Kambali Gandi Hidayanto', 'Jln. Camar No. 723, Dumai 57983, Gorontalo', '2009-06-09 10:26:02', '2020-10-16 14:20:59'),
(46, 'Faizah Kuswandari', 'Gg. Hang No. 232, Singkawang 97266, NTT', '1970-12-26 11:03:20', '2020-10-16 14:20:59'),
(47, 'Bakijan Gaiman Sinaga', 'Ki. Suniaraja No. 381, Sukabumi 86713, KalBar', '1991-12-14 18:47:35', '2020-10-16 14:20:59'),
(48, 'Jarwa Maryadi', 'Dk. Rajiman No. 407, Bogor 37289, SumUt', '1992-02-15 02:34:02', '2020-10-16 14:20:59'),
(49, 'Hasta Ramadan', 'Dk. Zamrud No. 120, Kotamobagu 15326, Maluku', '1973-08-11 20:05:04', '2020-10-16 14:21:00'),
(50, 'Ida Lestari S.E.I', 'Dk. Arifin No. 666, Surakarta 63403, Riau', '1979-10-25 23:49:43', '2020-10-16 14:21:00'),
(51, 'Dimas Sihombing S.E.I', 'Jln. Wahidin No. 849, Pekanbaru 68739, MalUt', '1997-10-06 02:10:36', '2020-10-16 14:21:00'),
(52, 'Niyaga Latif Damanik M.M.', 'Psr. Jend. Sudirman No. 433, Jambi 28964, DIY', '2000-12-17 01:31:56', '2020-10-16 14:21:00'),
(53, 'Devi Laksmiwati', 'Jr. Kartini No. 769, Kupang 61728, KalTim', '2010-07-07 09:36:55', '2020-10-16 14:21:00'),
(54, 'Panca Adriansyah', 'Kpg. Acordion No. 675, Kendari 49933, SulSel', '1988-12-21 16:54:55', '2020-10-16 14:21:00'),
(55, 'Bakiman Kardi Putra', 'Psr. Industri No. 848, Pasuruan 66956, SumSel', '2014-07-31 08:01:34', '2020-10-16 14:21:00'),
(56, 'Yessi Chelsea Agustina S.Psi', 'Ds. Yogyakarta No. 238, Pekalongan 91500, Bali', '2010-01-07 00:18:55', '2020-10-16 14:21:00'),
(57, 'Zelda Melani', 'Kpg. Labu No. 388, Blitar 37865, KalBar', '2006-08-23 14:53:33', '2020-10-16 14:21:00'),
(58, 'Dewi Anastasia Aryani', 'Jln. Bakau Griya Utama No. 885, Administrasi Jakarta Barat 12867, SumUt', '1981-10-25 13:41:50', '2020-10-16 14:21:00'),
(59, 'Cindy Gawati Widiastuti S.Gz', 'Ki. Eka No. 137, Tidore Kepulauan 37897, JaBar', '2003-02-20 20:11:34', '2020-10-16 14:21:00'),
(60, 'Agnes Ellis Usada', 'Ki. Madiun No. 964, Bau-Bau 21811, Bengkulu', '1996-03-24 06:34:52', '2020-10-16 14:21:00'),
(61, 'Paris Widiastuti', 'Jr. Pacuan Kuda No. 45, Administrasi Jakarta Timur 54964, Lampung', '1989-01-17 16:58:36', '2020-10-16 14:21:00'),
(62, 'Yuni Mutia Novitasari', 'Dk. Kartini No. 342, Bontang 34181, Bengkulu', '1983-04-13 20:12:34', '2020-10-16 14:21:00'),
(63, 'Emin Galuh Prasetya S.Sos', 'Kpg. Sugiono No. 990, Surabaya 76939, DKI', '1984-11-14 15:00:26', '2020-10-16 14:21:01'),
(64, 'Fitria Hasanah', 'Ds. Setiabudhi No. 339, Kediri 20244, NTT', '1986-11-12 12:51:23', '2020-10-16 14:21:01'),
(65, 'Saka Wibowo', 'Jln. Cikapayang No. 667, Balikpapan 31393, Banten', '1979-08-17 19:11:31', '2020-10-16 14:21:01'),
(66, 'Teddy Nainggolan', 'Dk. Lembong No. 110, Kendari 13077, KalUt', '1990-11-13 16:22:13', '2020-10-16 14:21:01'),
(67, 'Ikhsan Firgantoro', 'Psr. Hang No. 122, Binjai 75875, JaTeng', '1981-09-13 01:33:34', '2020-10-16 14:21:01'),
(68, 'Suci Kezia Winarsih', 'Jr. Pasteur No. 91, Pekalongan 72044, Banten', '2011-11-14 20:44:43', '2020-10-16 14:21:01'),
(69, 'Lantar Bajragin Samosir S.Sos', 'Ki. Baja Raya No. 773, Parepare 44223, JaTeng', '2009-01-13 22:38:21', '2020-10-16 14:21:01'),
(70, 'Titin Astuti', 'Jln. Rajiman No. 869, Tidore Kepulauan 74161, SulBar', '1976-04-26 08:15:45', '2020-10-16 14:21:01'),
(71, 'Hesti Vivi Widiastuti', 'Gg. Tangkuban Perahu No. 154, Kotamobagu 55832, KalUt', '2020-01-12 12:48:22', '2020-10-16 14:21:01'),
(72, 'Ulva Pertiwi', 'Gg. W.R. Supratman No. 431, Tegal 22504, SumBar', '1980-04-12 16:34:23', '2020-10-16 14:21:01'),
(73, 'Jarwa Dongoran', 'Ds. Jambu No. 657, Depok 17345, Aceh', '1987-02-27 13:33:07', '2020-10-16 14:21:01'),
(74, 'Vicky Tari Utami', 'Ds. Bak Air No. 656, Bengkulu 28558, MalUt', '1998-10-17 17:42:50', '2020-10-16 14:21:01'),
(75, 'Cahya Perkasa Maryadi', 'Jr. Lumban Tobing No. 47, Bandar Lampung 44653, KepR', '1980-06-07 13:49:39', '2020-10-16 14:21:01'),
(76, 'Paramita Usada', 'Kpg. Banceng Pondok No. 41, Binjai 61952, SumUt', '1998-08-12 15:22:53', '2020-10-16 14:21:01'),
(77, 'Qori Winarsih S.Kom', 'Jln. Warga No. 619, Cimahi 51033, BaBel', '2004-05-23 12:30:10', '2020-10-16 14:21:01'),
(78, 'Darmaji Dongoran', 'Psr. R.M. Said No. 436, Balikpapan 79546, SulTra', '1991-09-06 23:37:23', '2020-10-16 14:21:01'),
(79, 'Kala Gamanto Irawan S.Ked', 'Jln. M.T. Haryono No. 237, Kediri 44982, DIY', '2003-10-12 00:16:37', '2020-10-16 14:21:01'),
(80, 'Asirwanda Hutasoit', 'Gg. Batako No. 112, Tebing Tinggi 54485, Gorontalo', '2001-11-29 20:58:53', '2020-10-16 14:21:02'),
(81, 'Calista Yulianti', 'Dk. Pahlawan No. 876, Manado 39213, SulTra', '2011-12-14 17:22:17', '2020-10-16 14:21:02'),
(82, 'Bella Fujiati', 'Gg. Honggowongso No. 194, Bengkulu 49995, Bali', '2005-08-24 15:55:27', '2020-10-16 14:21:02'),
(83, 'Keisha Namaga S.Ked', 'Ki. Krakatau No. 766, Ambon 18343, SulBar', '2003-03-18 01:15:51', '2020-10-16 14:21:02'),
(84, 'Ulva Puspasari S.Pd', 'Psr. Ters. Pasir Koja No. 727, Jayapura 28723, KalTeng', '1982-06-04 15:41:36', '2020-10-16 14:21:02'),
(85, 'Zalindra Juli Uyainah', 'Psr. Adisumarmo No. 569, Bengkulu 50867, MalUt', '1995-12-24 00:53:55', '2020-10-16 14:21:02'),
(86, 'Raihan Mandala', 'Psr. Villa No. 376, Denpasar 13460, SulTra', '1988-09-14 18:42:34', '2020-10-16 14:21:02'),
(87, 'Samiah Halimah', 'Ki. Basoka Raya No. 836, Tebing Tinggi 95436, Gorontalo', '1993-04-16 09:22:13', '2020-10-16 14:21:03'),
(88, 'Galuh Simanjuntak', 'Dk. Basmol Raya No. 399, Tangerang Selatan 68384, SulBar', '2012-11-28 17:49:04', '2020-10-16 14:21:03'),
(89, 'Kajen Rajata', 'Ds. Suprapto No. 152, Kotamobagu 94043, KalSel', '1982-12-05 15:50:09', '2020-10-16 14:21:03'),
(90, 'Harto Ganjaran Prasetya M.M.', 'Ki. Imam No. 939, Ambon 35894, KalTeng', '1970-07-01 05:39:36', '2020-10-16 14:21:03'),
(91, 'Fathonah Pertiwi S.I.Kom', 'Psr. Jaksa No. 607, Salatiga 35725, Bali', '2013-02-22 18:32:01', '2020-10-16 14:21:03'),
(92, 'Elvina Yolanda S.Sos', 'Gg. Umalas No. 171, Serang 60220, PapBar', '2017-03-27 08:19:18', '2020-10-16 14:21:03'),
(93, 'Jarwi Sinaga M.TI.', 'Psr. Bakti No. 385, Tangerang Selatan 75542, JaBar', '2013-08-06 16:06:58', '2020-10-16 14:21:03'),
(94, 'Hilda Palastri', 'Ds. Jend. A. Yani No. 479, Bengkulu 33706, Bengkulu', '1975-08-25 08:16:40', '2020-10-16 14:21:03'),
(95, 'Gabriella Yulianti', 'Jr. Panjaitan No. 570, Balikpapan 19771, KepR', '1988-02-19 12:55:59', '2020-10-16 14:21:03'),
(96, 'Warsa Mustofa', 'Gg. Sudiarto No. 822, Pekanbaru 39817, Gorontalo', '1971-04-29 18:28:01', '2020-10-16 14:21:03'),
(97, 'Kawaca Soleh Nugroho M.Kom.', 'Jr. Cemara No. 177, Tegal 93392, Aceh', '1981-11-06 20:03:16', '2020-10-16 14:21:03'),
(98, 'Muhammad Ozy Wacana', 'Gg. Tangkuban Perahu No. 678, Langsa 11745, SulTeng', '1974-11-26 07:49:02', '2020-10-16 14:21:03'),
(99, 'Tina Novitasari M.Pd', 'Jr. Raden Saleh No. 107, Kupang 35174, DIY', '1996-12-03 06:56:52', '2020-10-16 14:21:04'),
(100, 'Dariati Prima Ramadan', 'Ds. Gajah Mada No. 963, Pontianak 34448, SulSel', '1984-02-03 19:29:06', '2020-10-16 14:21:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komik`
--
ALTER TABLE `komik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orang`
--
ALTER TABLE `orang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komik`
--
ALTER TABLE `komik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orang`
--
ALTER TABLE `orang`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
